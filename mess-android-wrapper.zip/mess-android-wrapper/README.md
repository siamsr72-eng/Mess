# Mess Android wrapper

This project wraps the Mess web app in an Android WebView and includes a GitHub Actions workflow that builds a debug APK.

## Build APK on GitHub

1. Create a GitHub repository and upload all files in this folder.
2. Push the files to the `main` branch.
3. Open the repository's **Actions** tab.
4. Select **Build Mess APK** and choose **Run workflow** (or let it run after pushing).
5. Open the completed workflow run and download the `Mess-debug-APK` artifact.
6. Extract the downloaded artifact ZIP to get `app-debug.apk`.
7. Transfer `app-debug.apk` to your Android phone and open it to install. You may need to allow installation from that file manager/browser.

This is a debug APK for personal testing, not a Play Store release. Android may show a warning because it is not signed with a Play Store release key.

## Local build

Requires JDK 17, Android SDK with API 35 installed, and Gradle 8.9:
`gradle assembleDebug`

Output: `app/build/outputs/apk/debug/app-debug.apk`

## Data

The app loads the web app from local Android assets. Data is stored locally in the app's WebView storage and does not sync across devices. Uninstalling the app or clearing its storage may erase data; export/backup any important records first.
