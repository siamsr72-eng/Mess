# Expenses Android app

This project wraps the Expenses tracker in an Android WebView. The Android application ID is `com.expenses.app`, so installing it does not replace the older `com.mess.app` installation. The launcher name is **Expenses**.

## Features
- Expense rows sort by date, oldest first (1 January before 31 January).
- The **Expense details** dialog shows totals and each person's comparison with the overall average; there is no person-to-person comparison.
- Local-first storage: changes are saved on the phone immediately and work offline.
- Optional Google Drive backup using the private Drive `appDataFolder`; backup uploads are delayed briefly after changes and retry on later changes when online.
- Restore is explicit and confirms before replacing local data. When connecting an account that already has a cloud backup, choose whether to restore it or keep the phone's data.

## Required Google setup before cloud backup can work
The Drive implementation is included, but Google sign-in will not work until you configure a Google Cloud project for your own build/signing certificate. No credentials are embedded in the app.

1. In Google Cloud Console, create/select a project and enable **Google Drive API**.
2. Configure the OAuth consent screen and add your Google account as a test user if the app is in testing mode.
3. Create an **OAuth client ID of type Android** with package name `com.expenses.app` and the SHA-1 signing certificate of the APK you install.
4. Install an APK signed with that same certificate. A debug APK built on a fresh GitHub Actions runner may have a different generated debug certificate on each run; for reliable sign-in, use a stable signing key and register its SHA-1. Never commit a private release keystore or password to the repository.
5. Open Expenses, tap the cloud icon, connect your Google account, and approve the requested Drive app-data access.

The backup is a single JSON file named `expenses-backup.json` inside Drive's hidden `appDataFolder`, not a visible file in My Drive. Google Drive stores it under the authorized account.

## Build APK on GitHub Actions
1. Upload this folder's contents to your repository (or place this folder at repository root).
2. Push to `main`/`master` or run the **Build Expenses APK** workflow manually.
3. Download the `Expenses-debug-APK` artifact from the completed workflow and extract `app-debug.apk`.

## Local build
Requires JDK 17, Android SDK API 35, and Gradle 8.9. Run `gradle assembleDebug`. Output: `app/build/outputs/apk/debug/app-debug.apk`.

## Data safety
Keep a separate backup of important data until you have successfully connected Google Drive and confirmed a successful backup. Uninstalling or clearing app storage can remove local records. Restoring from Drive replaces current local app data after an explicit confirmation.
