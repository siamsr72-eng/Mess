package com.expenses.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.gms.auth.GoogleAuthUtil;
import com.google.android.gms.auth.UserRecoverableAuthException;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Scope;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int RC_SIGN_IN = 7104;
    private static final String DRIVE_SCOPE = "https://www.googleapis.com/auth/drive.appdata";
    private static final String BACKUP_NAME = "expenses-backup.json";
    private static final String PREFS = "expenses_drive";
    private WebView webView;
    private GoogleSignInClient signInClient;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private String latestJson = "{}";
    private boolean syncing;
    private final Runnable delayedSync = () -> syncLocalToDrive(false);
    private ConnectivityManager.NetworkCallback networkCallback;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(245,247,251));
        getWindow().setNavigationBarColor(Color.rgb(245,247,251));
        GoogleSignInOptions options = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail().requestScopes(new Scope(DRIVE_SCOPE)).build();
        signInClient = GoogleSignIn.getClient(this, options);
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); settings.setDomStorageEnabled(true); settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true); settings.setAllowContentAccess(true); settings.setSupportZoom(false);
        webView.addJavascriptInterface(new DriveBridge(), "NativeDrive");
        webView.setWebViewClient(new WebViewClient()); webView.setWebChromeClient(new WebChromeClient());
        webView.setBackgroundColor(Color.rgb(245,247,251)); setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
        ConnectivityManager cm = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
        if (cm != null) {
            networkCallback = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network network) {
                    handler.postDelayed(() -> { if (GoogleSignIn.getLastSignedInAccount(MainActivity.this) != null) syncLocalToDrive(false); }, 1800);
                }
            };
            try { cm.registerNetworkCallback(new NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build(), networkCallback); } catch (Exception ignored) {}
        }
    }

    private class DriveBridge {
        @JavascriptInterface public void onLocalDataChanged(String json) {
            latestJson = json == null ? "{}" : json;
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("latest_json", latestJson).apply();
            if (GoogleSignIn.getLastSignedInAccount(MainActivity.this) != null) {
                handler.removeCallbacks(delayedSync); handler.postDelayed(delayedSync, 4500);
            }
        }
        @JavascriptInterface public void manageBackup() { runOnUiThread(() -> showBackupMenu()); }
        @JavascriptInterface public String backupStatus() {
            GoogleSignInAccount a = GoogleSignIn.getLastSignedInAccount(MainActivity.this);
            return a == null ? "Not connected" : "Connected: " + (a.getEmail() == null ? "Google account" : a.getEmail());
        }
    }

    private void showBackupMenu() {
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
        String[] actions = account == null
                ? new String[]{"Connect Google Drive", "About backup"}
                : new String[]{"Back up now", "Restore from Google Drive", "Disconnect Google account", "About backup"};
        new AlertDialog.Builder(this).setTitle("Expenses cloud backup")
                .setItems(actions, (d, which) -> {
                    if (account == null) { if (which == 0) startActivityForResult(signInClient.getSignInIntent(), RC_SIGN_IN); else showAbout(); }
                    else if (which == 0) syncLocalToDrive(true);
                    else if (which == 1) restoreFromDrive();
                    else if (which == 2) signInClient.signOut().addOnCompleteListener(t -> { getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove("last_file_id").apply(); message("Google account disconnected."); });
                    else showAbout();
                }).show();
    }

    private void showAbout() {
        new AlertDialog.Builder(this).setTitle("About Google Drive backup")
          .setMessage("Expenses saves data on this phone first. When Google Drive is connected and internet is available, changes are uploaded to the private appDataFolder in your Google Drive. First connection will ask whether to restore an existing cloud backup or keep this phone's data. Restore replaces local data, so choose carefully.")
          .setPositiveButton("OK", null).show();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            try {
                GoogleSignInAccount account = GoogleSignIn.getSignedInAccountFromIntent(data).getResult(ApiException.class);
                message("Connected to " + account.getEmail());
                io.execute(() -> inspectCloudAfterConnect(account));
            } catch (Exception e) { message("Google sign-in failed. Check Google Cloud OAuth setup and try again."); }
        }
    }

    private boolean online() {
        ConnectivityManager cm = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
        Network n = cm == null ? null : cm.getActiveNetwork();
        NetworkCapabilities c = n == null ? null : cm.getNetworkCapabilities(n);
        return c != null && c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET);
    }
    private String accessToken(GoogleSignInAccount account) throws Exception {
        try { return GoogleAuthUtil.getToken(this, account.getAccount(), "oauth2:" + DRIVE_SCOPE); }
        catch (UserRecoverableAuthException e) { runOnUiThread(() -> startActivityForResult(e.getIntent(), 7105)); throw e; }
    }
    private JSONObject request(String method, String urlText, String token, byte[] body, String contentType) throws Exception {
        HttpURLConnection c = (HttpURLConnection)new URL(urlText).openConnection();
        c.setRequestMethod(method); c.setConnectTimeout(20000); c.setReadTimeout(20000);
        c.setRequestProperty("Authorization", "Bearer " + token); c.setRequestProperty("Accept", "application/json");
        if (body != null) { c.setDoOutput(true); c.setRequestProperty("Content-Type", contentType); try(OutputStream out=c.getOutputStream()){out.write(body);} }
        int code=c.getResponseCode(); InputStream stream=code>=200&&code<300?c.getInputStream():c.getErrorStream();
        String text=""; if(stream!=null){ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=stream.read(buf))!=-1)b.write(buf,0,n);text=b.toString("UTF-8");stream.close();}
        c.disconnect(); if(code<200||code>=300)throw new Exception("Drive API HTTP "+code+": "+text); return text.isEmpty()?new JSONObject():new JSONObject(text);
    }
    private JSONObject findBackup(String token) throws Exception {
        String q=URLEncoder.encode("name='"+BACKUP_NAME+"' and 'appDataFolder' in parents and trashed=false", "UTF-8");
        return request("GET", "https://www.googleapis.com/drive/v3/files?q="+q+"&spaces=appDataFolder&fields=files(id,name,modifiedTime,size)", token, null, null);
    }
    private void inspectCloudAfterConnect(GoogleSignInAccount account) {
        try {
            String token=accessToken(account); JSONObject found=findBackup(token); JSONArray files=found.optJSONArray("files");
            if(files!=null && files.length()>0) {
                JSONObject file=files.getJSONObject(0); String id=file.getString("id");
                getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString("last_file_id",id).apply();
                runOnUiThread(() -> new AlertDialog.Builder(this).setTitle("Existing cloud backup found")
                    .setMessage("A backup already exists in this Google Drive. Restore it to this phone, or keep the data on this phone and upload it to Drive?")
                    .setPositiveButton("Restore cloud backup",(d,w)->restoreById(id))
                    .setNegativeButton("Keep phone data",(d,w)->syncLocalToDrive(true)).setCancelable(false).show());
            } else syncLocalToDrive(true);
        } catch(Exception e) { message("Connected, but Drive could not be checked. Verify internet and Google Drive API setup."); }
    }
    private void syncLocalToDrive(boolean showResult) {
        if (syncing) return;
        if (!online()) { if(showResult) message("Offline. Your data stays on this phone; backup will retry when online."); return; }
        GoogleSignInAccount account=GoogleSignIn.getLastSignedInAccount(this);
        if(account==null){if(showResult)runOnUiThread(()->startActivityForResult(signInClient.getSignInIntent(),RC_SIGN_IN));return;}
        syncing=true;
        io.execute(() -> {
            try {
                SharedPreferences prefs=getSharedPreferences(PREFS,MODE_PRIVATE);
                String json=prefs.getString("latest_json",latestJson); if(json==null||json.isEmpty())json="{}";
                String token=accessToken(account); JSONObject found=findBackup(token); JSONArray files=found.optJSONArray("files");
                String id=(files!=null&&files.length()>0)?files.getJSONObject(0).optString("id",""):"";
                String boundary="expenses_"+System.currentTimeMillis();
                String metadata=id.isEmpty()?"{\"name\":\""+BACKUP_NAME+"\",\"parents\":[\"appDataFolder\"]}":"{\"name\":\""+BACKUP_NAME+"\"}";
                String payload="{\"format\":1,\"app\":\"Expenses\",\"updatedAt\":"+System.currentTimeMillis()+",\"data\":"+json+"}";
                String multipart="--"+boundary+"\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n"+metadata+"\r\n--"+boundary+"\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n"+payload+"\r\n--"+boundary+"--\r\n";
                String endpoint=id.isEmpty()?"https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,modifiedTime":"https://www.googleapis.com/upload/drive/v3/files/"+id+"?uploadType=multipart&fields=id,name,modifiedTime";
                JSONObject result=request(id.isEmpty()?"POST":"PATCH",endpoint,token,multipart.getBytes(StandardCharsets.UTF_8),"multipart/related; boundary="+boundary);
                prefs.edit().putString("last_file_id",result.optString("id",id)).putLong("last_sync",System.currentTimeMillis()).apply();
                if(showResult)message("Backup saved to Google Drive.");
            } catch(Exception e) { if(showResult)message("Backup failed. Your phone data is safe; try again when online."); }
            finally { syncing=false; }
        });
    }
    private void restoreFromDrive() {
        if(!online()){message("Connect to the internet to restore.");return;}
        GoogleSignInAccount account=GoogleSignIn.getLastSignedInAccount(this);
        if(account==null){startActivityForResult(signInClient.getSignInIntent(),RC_SIGN_IN);return;}
        io.execute(()->{try{String token=accessToken(account);JSONObject f=findBackup(token);JSONArray a=f.optJSONArray("files");if(a==null||a.length()==0){message("No Expenses backup was found in this Google Drive.");return;}restoreById(a.getJSONObject(0).getString("id"));}catch(Exception e){message("Could not access the cloud backup. Try again.");}});
    }
    private void restoreById(String id) {
        GoogleSignInAccount account=GoogleSignIn.getLastSignedInAccount(this); if(account==null)return;
        io.execute(()->{try{
            String token=accessToken(account);JSONObject result=request("GET","https://www.googleapis.com/drive/v3/files/"+id+"?alt=media",token,null,null);
            JSONObject data=result.optJSONObject("data"); if(data==null)throw new Exception("Backup format not recognized");
            String json=data.toString();
            runOnUiThread(()->new AlertDialog.Builder(this).setTitle("Replace phone data?").setMessage("Restoring replaces the current data on this phone. Make sure you want to continue.")
                .setNegativeButton("Cancel",null).setPositiveButton("Restore",(d,w)->{webView.evaluateJavascript("localStorage.setItem('mess-app-v1', "+JSONObject.quote(json)+"); location.reload();",null);getSharedPreferences(PREFS,MODE_PRIVATE).edit().putString("latest_json",json).putString("last_file_id",id).apply();message("Cloud backup restored.");}).show());
        }catch(Exception e){message("Restore failed. The existing phone data was not changed.");}});
    }
    private void message(String msg) { runOnUiThread(()->new AlertDialog.Builder(this).setMessage(msg).setPositiveButton("OK",null).show()); }
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);ConnectivityManager cm=(ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);if(cm!=null&&networkCallback!=null){try{cm.unregisterNetworkCallback(networkCallback);}catch(Exception ignored){}}if(webView!=null)webView.destroy();io.shutdown();super.onDestroy();}
}
